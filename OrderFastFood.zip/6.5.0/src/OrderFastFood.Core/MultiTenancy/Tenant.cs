﻿using Abp.MultiTenancy;
using OrderFastFood.Authorization.Users;

namespace OrderFastFood.MultiTenancy
{
    public class Tenant : AbpTenant<User>
    {
        public Tenant()
        {
            
        }

        public Tenant(string tenancyName, string name)
            : base(tenancyName, name)
        {
        }
    }
}