﻿namespace OrderFastFood
{
    public class OrderFastFoodConsts
    {
        public const string LocalizationSourceName = "OrderFastFood";

        public const bool MultiTenancyEnabled = true;
        
        /// <summary>
        /// Default pass phrase for SimpleStringCipher decrypt/encrypt operations
        /// </summary>
        public const string DefaultPassPhrase = "4edafb71eeab4ff099e38f10ce09401e";
    }
}