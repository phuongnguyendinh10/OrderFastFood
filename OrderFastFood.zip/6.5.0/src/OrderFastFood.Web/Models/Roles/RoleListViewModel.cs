﻿using System.Collections.Generic;
using OrderFastFood.Roles.Dto;

namespace OrderFastFood.Web.Models.Roles
{
    public class RoleListViewModel
    {
        public IReadOnlyList<RoleDto> Roles { get; set; }

        public IReadOnlyList<PermissionDto> Permissions { get; set; }
    }
}