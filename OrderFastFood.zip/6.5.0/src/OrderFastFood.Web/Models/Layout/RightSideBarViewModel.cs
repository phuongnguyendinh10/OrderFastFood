using OrderFastFood.Configuration.Ui;

namespace OrderFastFood.Web.Models.Layout
{
    public class RightSideBarViewModel
    {
        public UiThemeInfo CurrentTheme { get; set; }
    }
}